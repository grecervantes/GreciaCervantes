//
//  canciones.swift
//  SegundoParcial
//
//  Created by Macbook on 5/21/19.
//  Copyright © 2019 Guest User. All rights reserved.
//


struct Album {
    
    
    var canciones: String
    var titulo:String
    var precio : String
    
    
}
