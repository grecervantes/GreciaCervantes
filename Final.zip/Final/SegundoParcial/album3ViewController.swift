//
//  album3ViewController.swift
//  SegundoParcial
//
//  Created by Macbook on 5/22/19.
//  Copyright © 2019 Guest User. All rights reserved.
//

import UIKit

class album3ViewController: UIViewController {

    let album3:[Album] = [
        
        Album(canciones: "3", titulo: "Cuando llegas/ Cafe tacvba / Nº de canciones 3",precio:"¢20 / Duracion:3.20 / Año 1996"),
        Album(canciones: "3",titulo: "Sky- Cafe tacvba - Nº de canciones 3",precio:"¢20 / Duracion:3.15 / Año 1996"),
        Album(canciones:"3",titulo: "Mascarita- Cafe tacvba - Nº de canciones 3",precio:"¢35 / Duracion:3.30 / Año 1996"),
        
        
        ]
    let secciones = "album3"
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
